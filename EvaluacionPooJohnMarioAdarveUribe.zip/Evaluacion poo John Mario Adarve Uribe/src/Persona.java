
public class Persona {
	// 1. atributos de la clase persona
	 private String nombre;
	 private String direccion;
	 private String telefono;
	 private String email;
	 
	 //// 2. Definir el constructor de la clase 
	 
		Persona (String nombre,String direccion,String telefono,String email){
			 this.nombre = nombre;
			 this.direccion = direccion;
			 this.telefono = telefono;
			 this.email = email;
		 }
		// metodos de la clase AUTOMATICOS

		
	 public String getNombre() {
		return nombre;
	}



	public void setNombre(String nombre) {
		this.nombre = nombre;
	}



	public String getDireccion() {
		return direccion;
	}



	public void setDireccion(String direccion) {
		this.direccion = direccion;
	}



	public String getTelefono() {
		return telefono;
	}



	public void setTelefono(String telefono) {
		this.telefono = telefono;
	}



	public String getEmail() {
		return email;
	}



	public void setEmail(String email) {
		this.email = email;
	}
	
	// metodos del objeto (imprime todos los atributos del objeto.)
		
	
	 
	 
	 
	@Override
	public String toString() {
		return "Persona " + nombre + " \ndireccion=" + direccion + "\ntelefono=" + telefono + "\\nemail=" + email
				;
	}
	 
}

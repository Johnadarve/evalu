
public class Empleado extends Persona{
	private String depto;
	private double salario;
	private String fechacontra;
	
//. Definir el constructor de la clase
	public Empleado(String nombre, String direccion, String telefono, String email,String depto,double salario,String fechacontra) {
		super(nombre, direccion, telefono, email);
		this.depto = depto;
		this.salario = salario;
		this.fechacontra = fechacontra;
	}

	public String getDepto() {
		return depto;
	}

	public void setDepto(String depto) {
		this.depto = depto;
	}

	public double getSalario() {
		return salario;
	}

	public void setSalario(double salario) {
		this.salario = salario;
	}

	public String getFechacontra() {
		return fechacontra;
	}

	public void setFechacontra(String fechacontra) {
		this.fechacontra = fechacontra;
		
		
	}
	
	// metodo para insertar empleado 
	public void NuevoEmpleado() {
		System.out.println("El empleado fue insertado correctamente");
		}


	@Override
	public String toString() {
		return "Empleado " + depto + ", salario=" + salario + ", fechacontra=" + fechacontra + ", getDepto()="
				+ getDepto() + ", getSalario()=" + getSalario() + ", getFechacontra()=" + getFechacontra()
				+ ", getNombre()=" + getNombre() + ", getDireccion()=" + getDireccion() + ", getTelefono()="
				+ getTelefono() + ", getEmail()=" + getEmail() + ", toString()=" + super.toString() + ", getClass()="
				+ getClass() + ", hashCode()=" + hashCode() + "]";
	}
	

	
}

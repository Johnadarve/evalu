import java.util.Scanner;

public class Empresa {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		System.out.println("****Empresa****");
		
		 
		Scanner leer = new Scanner(System.in);

		Estudiante Estudiante = new Estudiante("Juan","cra 59","56","afgjash",1,5.5);
		System.out.println(Estudiante);
		
		
		
		
	
		

		
		leer.close();
	}

}

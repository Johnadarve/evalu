
public class Estudiante extends Persona {
	private int estado;
	private double promedio;
	
	public double getPromedio() {
		return promedio;
	}


	public void setPromedio(double promedio) {
		this.promedio = promedio;
	}


	public Estudiante (String nombre,String direccion,String telefono,String email,int estado,double promedio) {
	super (nombre,direccion,telefono,email); // herencia de persona
	this.estado = estado;
	this.promedio = promedio;
	}

	
	public int getEstado() {
		return estado;
	}

	public void setEstado(int estado) {
		this.estado = estado;
	}
	
	// metodo para insertar estudiante
	
	public void NuevoEstudiante() {
		System.out.println("El estudiante fue insertado correctamente");
		}

	@Override
	public String toString() {
		return "Estudiante\n" + estado + " Estado \n" + getEstado() + " Nombre\n" + getNombre()
				+ " Direccion \n" + getDireccion() + "Telefono \n " + getTelefono() + "Email\n"
				+ getEmail() + " String \n" + super.toString() + ", getClass()=" + getClass() + ", hashCode()="
				+ hashCode() + "]"+getPromedio()+"promedio"+ promedio;
	}
	

}
